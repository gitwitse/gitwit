module.exports = {
	showLogo: true,
	defaultColor: 'white',
	selectorColor: 'red',
	accentColor: 'white',
	appResize: true,
	showFlag: false,
	changeBold: true,
	changeBorder: 'double'
}