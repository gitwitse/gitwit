# Git-Wit
Git-Wit is an app for using Git/GitHub functionality for your terminal