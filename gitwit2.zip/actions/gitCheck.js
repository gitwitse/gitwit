const { execSync } = require("child_process");

const gitCheck = () => {
	execSync("git rev-parse --is-inside-work-tree",
		(error, stdout, stderr) => {
			if (error) 
				return false;
            return true;
		}
	);
	
}

module.exports = gitCheck;