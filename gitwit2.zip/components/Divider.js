const React = require('react')
const {Text} = require('ink');

const Renderer = (props) => {
	let divider = '='.repeat(props.width)
	return divider
}

module.exports = Renderer
